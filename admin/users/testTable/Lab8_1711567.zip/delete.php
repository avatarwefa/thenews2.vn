<?php  
 $connect = mysqli_connect("localhost", "root", "", "examples");  
 $sql = "DELETE FROM cars WHERE id = '".$_POST["id"]."'";  
 if(mysqli_query($connect, $sql))  
 {  
      echo 'Xoá dữ liệu';  
 }  
 ?>