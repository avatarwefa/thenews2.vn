<?php  
 $connect = mysqli_connect("localhost", "root", "", "examples");  

 $sql = "INSERT INTO cars(name, year) VALUES('".$_POST["name"]."', '".$_POST["year"]."')";  
 if(mysqli_query($connect, $sql))  
 {  
      echo 'Thêm dữ liệu';  
 }  
 ?> 